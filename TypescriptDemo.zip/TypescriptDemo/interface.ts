//CREATE INTERFACE --> use classes when you want to retain the type (preferred classes in backend especially) (javascript doesnt use interfaces)
export interface User {
    name: string;
    age?: number;   //make age optional --> age?
    id: number;
    email: string;
}

//Use interface without all properties being provided
let user : User = { name: 'John', id: 1, email: ''}; //age is optional so can leave it out

//Object Destructuring
let { name: userName, email }: User = { name: "John", id: 1, email: ""}; //only access name + email out of the 3 properties. Can say: let { name: userName, email}...etc. if want to access name as userName. Can do the same for email
//userName = ""; can now do this.

//Extend Interface
interface Employees extends User {
    salary: number;
}

let employee: Employees = { name: "John", id: 1, email: "", salary: 1000 }; // extended User to Employees to add salary variable

//Interface Method Definition
export interface Login {    //object that needs to be used outside, needs to have 'export' keyword
    Login(): User; //class can implement this method
}

//Array destructuring
let [user1, user2, ...restUsers]: User[] = [
    { name: "John", id: 1, email: ""},
    { name: 'John1', id: 2, email: ''},
    { name: 'John2', id: 3, email: ''},
    { name: 'John3', id: 4, email: ''}
];

console.log(user1);
console.log(user2);
console.log(restUsers);

//Filter
// let result = restUsers.filter(user => user.id > 3);


//DECORATORS
/*@Component({})          //probably will never really use this
class Component {
    constructor(public name: string) { }
}*/

//CAN CHANGE '"outDir": "./..."" TO THE NAME OF A NEW FILE WHERE YOU WANT ALL YOUR OUTPUT TO GO, e.g. "outDir": "./dist", --> will create new 'dist' file and store: class, datatypes, functions, interface.js files
