import { Login, User } from './interface'; //ctrl + spacebar in between curly brackets to see what can be imported

//INTERFACE
interface Address {
    street: string;
    city: string;
    state: string;
    pin: string;
}

//CLASSES
class Employee implements Login { //error will appear after typing 'implements Login', click the light bulb and then 'Implement Login'...will then fix the error and Login implementation will appear further down.
    #id: number;  //if no constructor, '!' after variable removes the error. Can make a property private by typing a '#' infront of it, e.g. #id, but then the 'hash' must also be put in the constructor for that property

    protected name: string;  //protected makes the variable available within the class and whatver class extends this one, but no public instances outside of that can access it

    //address: string; -->  would type this if there was no interface

    address: Address;

    //getter/setter
    get empId(): number {
        return this.#id;
    }

    set empId(id: number) {
        this.#id = id;
    }


    static getEmployeeCount(): number {     //static members (called at lower down)
        return 50;
    }


    constructor(id: number, name: string, address: Address) {
        this.address = address
        this.#id = id            //for the abovementioned private property --> this.#id = id
        this.name = name
    }


    Login(): User {                                //will have to also export/import user now because using it from 'interface'
        return { name: 'John', id: 1, email: ''}; //delete error line here and replace with what you need
    }

    //METHODS
    getNameWithAddress(): string {
        return this.name + " ; " + this.address;    // another way to concatenate: return `${this.name} stays at ${this.address}`; --> using tilde (`)
    }

}

//class to Extend Employee (aka Inheritance)
class Manager extends Employee {
    //can access employee properties here

    constructor(id: number, name: string, address: Address) {
        super(id, name, address);       //required when extending
    }

    getNameWithAddress(): string {
        return `${this.name} is a manager at ${this.address}`;
    }
}


//Create instance of the class
let john = new Employee(1, "John", { 
    street: "ABC", 
    city: "Bangalore", 
    state: "Karnataka", 
    pin: "560076", 
});

john.empId = 100; //set id
console.log(john.empId); //get id

let address = john.getNameWithAddress();

Employee.getEmployeeCount(); //call method on class itself

console.log(address);

let Mike = new Manager(2, "Mike", {
    street: "DEF",
    city: "Bangalore",
    state: "Karnataka",
    pin: "6001",
}); // uses new manager class

console.log(Mike.getNameWithAddress()); //If you delete Manager extension class, it will call the older 'getNameWithAddress' from parent class (... stays at ...)