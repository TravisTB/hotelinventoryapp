//WAYS TO WRITE A FUNCTION
//first way - named function
function add(a : number, b : number) {
    return a + b;
}

console.log(add(2,3));

//second way - arrow function
const sub = (num1: number, num2: number) : number => num1 - num2;
console.log(sub(2, 3));

//third way - function expression
const mult = function(num1: number, num2: number): number {
    return num1 * num2;
}

console.log(mult(2, 3));

//PARAMETERS
//optional parameter
function add2(a : number, b : number, c? : number) {
    return c? a + b + c : a + b;   //if-else statement in a single line (if c exists: a+b+c else a+b)
}

console.log(add2(2, 3, 4));

//required parameter
const sub2 = (num1: number, num2: number, num3 = 10) : number => num1 - num2 - num3;
console.log(sub2(2, 3));
console.log(sub2(2, 3, 5)); //5 is used instead of 10 if stated here

//rest parameter
function add3(num1: number, num2: number, ...num3: number[]): number{
    return num1 + num2 + num3.reduce((a, b) => a + b, 0);
}

let numbers = [1, 2, 3, 4, 5]
console.log(add3(2, 3, ...numbers));
console.log(add3(2, 3, ...[1,2,3,4,5])); //can also do it this way
console.log(add3(2, 3, 1, 2, 3, 4, 5)) //or this way (numbers after the first 3, will be seen as the num3 in the function above)

//GENERIC FUNCTION
function getItems<Type>(items: Type[]): Type[] {    //'Type' is a placeholder and doesnt mean anything
    return new Array<Type>().concat(items);
}

let concatResult = getItems([1, 2, 3, 4, 5]); // or: let concatResult = getItems<number>([1, 2, 3, 4, 5]);

let concatString = getItems(["a", "b", "c", "d", "e"]); // or: let concatString = getItems<string>(["a", "b", "c", "d", "e"]);