//String
let lname : string;
lname = "Te Brugge";
let newname = lname.toUpperCase();
console.log(newname);

//Number
let age : number;
age = 21;

//Parse
let dob = "25";
let result = parseInt(dob);

//Boolean
let isValid : boolean = false;  //must be assigned otherwise returns error/undefined (strict mode = true in tsconfig)

//Array
let empList : string[];
empList = ["Travis","TravisTB","TravisTeBrugge"];
let emp = empList.find((emp) => emp === "TravisTB") //Find/check if specific employee exists


let numList = [1,2,3,4,5];
let results = numList.filter((num) => num > 2); //filter numbers > 2

let num = numList.find((num) => num === 2); //find the number 2 in array
let sum = numList.reduce((acc, num) => acc + num) //calculate sum until it reaches the end of the array

let depList : Array<string>; //different syntax to define array

console.log(num);
console.log(emp);
console.log(sum);

//Enum
const enum Color {                    // data type consisting of an unordered set of named values -> 'const' stores each enum value as an index value e.g. Red = 0
    Red,
    Green,
    Blue
}

let c: Color = Color.Blue;

//Tuples
let swapNumbs: [number,number];

function swapNumbers(num1:number, num2:number) : [number,number] {
    return [num2, num1]
}

swapNumbs = swapNumbers(10,20);
swapNumbs[0];

//Any
let department : any;       //try not to ever use any and use the appropriate data types

department = "IT";          
department = "10";
